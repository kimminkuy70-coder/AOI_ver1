"""애플리케이션 메인 윈도우 — 전체 흐름 조정자(orchestrator).

다음 페이지를 StackedWidget 로 갈아끼우며 흐름을 관리한다.
1) SetupPage           → 입력
2) SelectPage          → Stage 1 (Phase A / Phase B 양쪽 모두에서 재사용)
3) MatchPage           → Stage 2 (방향만 바꿔 재사용)
4) ResultPage          → 결과 + 엑셀 저장

세션 자동 저장 / 이어하기, 단계 전환 모달, 진행 상태 라벨도 여기서 처리한다.
"""

from __future__ import annotations

import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QMainWindow,
                              QMessageBox, QStackedWidget, QVBoxLayout, QWidget)

from .. import config, i18n
from ..models import session as session_mod
from ..models.result import FinalResult, MatchResult, MissEntry
from ..models.slot import ImageItem, ScanResult, Slot, scan
from ..utils import paths
from ..workers.batch_matcher import BatchMatcherWorker
from ..workers.features import FeatureWorker
from ..workers.thumbnailer import ThumbnailWorker
from .pages.match_page import MatchPage
from .pages.result_page import ResultPage
from .pages.select_page import SelectPage
from .pages.setup_page import SetupInput, SetupPage
from .widgets.loading_overlay import LoadingOverlay


# ---------------------------------------------------------------------------
# Phase identifiers
# ---------------------------------------------------------------------------
PHASE_NONE = "none"
PHASE_A_SELECT = "A_select"
PHASE_A_MATCH = "A_match"
PHASE_B_SELECT = "B_select"
PHASE_B_MATCH = "B_match"


class MainWindow(QMainWindow):

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(i18n.KO.APP_TITLE)

        # 화면 크기 프리셋 — 저장된 값이 있으면 그대로 적용 ---------------
        from ..utils import prefs as _prefs
        self._prefs = _prefs
        saved = _prefs.load().window_preset
        self._apply_window_preset(saved if saved else "보통", persist=False)
        # 가장 작은 preset(1120×760) 까지가 실용적 하한. 그보다 작으면 매칭
        # 후보 그리드와 측면 패널이 가로 스크롤을 일으킨다.
        self.setMinimumSize(1120, 720)

        self._stack = QStackedWidget(self)
        self.setCentralWidget(self._stack)

        # 페이지 ---------------------------------------------------------
        self._setup_page = SetupPage()
        self._select_page = SelectPage()
        self._match_page = MatchPage()
        self._result_page = ResultPage()

        for w in (self._setup_page, self._select_page,
                  self._match_page, self._result_page):
            self._stack.addWidget(w)

        # 화면 크기 메뉴 -------------------------------------------------
        self._build_view_menu()

        # 시그널 ---------------------------------------------------------
        self._setup_page.start_requested.connect(self._on_start)
        self._select_page.finished.connect(self._on_select_finished)
        self._select_page.state_changed.connect(self._schedule_autosave)
        self._match_page.match_confirmed.connect(self._on_match_confirmed)
        self._match_page.skipped_changed.connect(self._schedule_autosave)
        self._match_page.finished.connect(self._on_match_finished)
        self._result_page.new_session_requested.connect(self._new_session)

        # 자동 저장 타이머 -----------------------------------------------
        self._autosave_timer = QTimer(self)
        self._autosave_timer.setInterval(
            config.CONFIG.autosave_interval_s * 1000
        )
        self._autosave_timer.timeout.connect(self._autosave)
        self._autosave_timer.start()

        # 상태 -----------------------------------------------------------
        self._loading = LoadingOverlay(self)
        self._thumb_worker: Optional[ThumbnailWorker] = None
        self._feature_worker: Optional[FeatureWorker] = None
        self._batch_worker: Optional[BatchMatcherWorker] = None
        self._slot_queue: list[str] = []
        self._total_slots: int = 0
        self._current_slot_idx: int = 0
        self._all_selected_targets: dict[str, list[ImageItem]] = {}
        self._stage2_slot_queue: list[str] = []
        self._stage2_slot_idx: int = 0
        self._scan: Optional[ScanResult] = None
        self._input: Optional[SetupInput] = None
        self._phase: str = PHASE_NONE
        self._matches_a: list[MatchResult] = []
        self._matches_b: list[MatchResult] = []
        self._skipped_a: dict[str, list[ImageItem]] = defaultdict(list)
        self._skipped_b: dict[str, list[ImageItem]] = defaultdict(list)
        self._stage1_a_snapshot: dict | None = None
        self._stage1_b_snapshot: dict | None = None
        self._matched_val_keys_in_a: set[str] = set()
        self._working_xlsx: Optional[Path] = None
        self._template_used: Optional[Path] = None
        self._session_id: str = ""

        # 이어하기 ------------------------------------------------------
        QTimer.singleShot(50, self._maybe_resume)

    # ==================================================================
    # Entry / resume
    # ==================================================================
    def _maybe_resume(self) -> None:
        # 셋업 진입 시 항상 정확도 최신화 + 모델 카드 갱신
        self._refresh_models_safe()

        state = session_mod.load()
        if state is None or state.stage in ("setup", "result"):
            self._show_page(self._setup_page)
            return
        r = QMessageBox.question(
            self, i18n.KO.INFO_RESUME_TITLE, i18n.KO.INFO_RESUME_BODY,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if r != QMessageBox.StandardButton.Yes:
            session_mod.clear()
            self._show_page(self._setup_page)
            return

        # 입력 페이지에 값을 복원해두고 사용자가 검증 시작을 다시 누르도록 한다.
        # (스캔 결과/디렉토리 상태가 바뀌었을 수 있으므로 안전한 재시작.)
        self._setup_page.apply_state(
            ref_root=state.ref_root,
            val_root=state.val_root,
            ref_machine=state.ref_machine,
            val_machine=state.val_machine,
            mode=state.mode,
            threshold=state.threshold,
        )
        self._show_page(self._setup_page)

    def _refresh_models_safe(self) -> None:
        """학습 모듈 import / 평가 집계 실패가 셋업 화면을 막지 않도록 wrap."""
        try:
            from ..learning import evaluator as _ev
            _ev.refresh_accuracy()
        except Exception:
            pass
        try:
            self._setup_page.refresh_models()
        except Exception:
            pass

    def _active_model_name(self) -> str:
        """현재 active 모델 이름 (없으면 ``basic``)."""
        try:
            from ..learning import registry as _reg
            return _reg.get_active()
        except Exception:
            return "basic"

    def _resolve_slot_mismatch(self, sr: ScanResult) -> None:
        """ref/val 한쪽에만 있는 슬롯이 있을 때 사용자에게 매핑을 묻는다 (#23)."""
        from .widgets.slot_mapping_dialog import SlotMappingDialog
        # 안내 → 다이얼로그 열기 여부 묻기
        r = QMessageBox.question(
            self, i18n.KO.WARN_SLOT_MISMATCH_TITLE,
            i18n.KO.WARN_SLOT_MISMATCH_FMT.format(
                ref_only=", ".join(sr.ref_only) or "없음",
                val_only=", ".join(sr.val_only) or "없음",
            ) + "\n\n" + i18n.KO.SLOT_MAP_OPEN + " ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if r != QMessageBox.StandardButton.Yes:
            return

        from PyQt6.QtWidgets import QDialog
        dlg = SlotMappingDialog(sr.ref_only, sr.val_only, parent=self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        mapping = dlg.mapping
        if not mapping.pairs:
            return

        # 매핑된 슬롯 쌍을 ScanResult.slots 에 통합 (val 측을 ref 측 이름으로 합침)
        for ref_name, val_name in mapping.pairs:
            ref_slot = sr.slots.get(ref_name)
            val_slot = sr.slots.get(val_name)
            if ref_slot is None or val_slot is None:
                continue
            # val 사진을 ref 슬롯에 결합 — side 는 유지하되 slot 명만 일치시킴.
            from ..models.slot import ImageItem
            rebuilt_val_imgs = [
                ImageItem(slot=ref_name, path=it.path, side="val")
                for it in val_slot.val_images
            ]
            ref_slot.val_images = rebuilt_val_imgs
            # 매핑 적용된 val 슬롯은 제거
            sr.slots.pop(val_name, None)

        # ref_only / val_only 목록 갱신
        sr.ref_only = [s for s in sr.ref_only
                       if s not in {a for a, _ in mapping.pairs}]
        sr.val_only = [s for s in sr.val_only
                       if s not in {b for _, b in mapping.pairs}]

    def _make_groups(self, items: list[ImageItem]):
        """ImageItem 목록을 슬롯별로 pHash 그룹화 (#15)."""
        try:
            from ..models import group as _grp
            from ..utils import prefs as _prefs
        except Exception:
            return None
        if not items:
            return None
        by_slot: dict[str, list[ImageItem]] = defaultdict(list)
        for it in items:
            by_slot[it.slot].append(it)
        p = _prefs.load()
        try:
            return _grp.cluster(
                by_slot,
                similarity_threshold=float(p.group_similarity),
                min_group_size=int(p.group_min_size),
            )
        except Exception:
            return None

    # ==================================================================
    # Setup → Stage 1
    # ==================================================================
    def _on_start(self, inp: SetupInput) -> None:
        self._input = inp
        self._matches_a.clear()
        self._matches_b.clear()
        self._skipped_a.clear()
        self._skipped_b.clear()
        self._matched_val_keys_in_a.clear()
        self._all_selected_targets.clear()
        self._session_id = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")

        self._prepare_working_file(inp)

        self._loading.show_overlay(i18n.KO.LOAD_SCAN)
        QApplication.processEvents()

        sr = scan(inp.ref_root, inp.val_root)
        self._scan = sr

        common = sr.common_slot_names
        if not common:
            self._loading.hide_overlay()
            QMessageBox.warning(self, i18n.KO.APP_TITLE, i18n.KO.WARN_NO_SLOTS)
            return

        if sr.ref_only or sr.val_only:
            self._resolve_slot_mismatch(sr)

        self._loading.hide_overlay()

        # 슬롯 큐 초기화 — 슬롯 하나씩 순차 처리
        self._slot_queue = list(self._scan.common_slot_names)
        self._total_slots = len(self._slot_queue)
        self._current_slot_idx = 0
        self._phase = PHASE_A_SELECT
        self._enter_slot_select(0)

    def _on_thumbs_ready(self) -> None:
        self._loading.hide_overlay()
        assert self._input is not None
        # Phase 결정 → Stage 1 진입 -------------------------------------
        self._phase = PHASE_A_SELECT
        self._enter_stage1_phase_a()

    def _confirm_threshold_before_stage2(self) -> None:
        """Stage 2 진입 전 항상 임계치 확인 대화상자를 표시.

        추천값이 있으면 통계와 함께 Y/N 으로 묻고,
        없으면 현재 값 확인 후 Y/N.
        어느 경우든 N 이면 직접 입력 대화상자로 이어진다.
        """
        if self._input is None:
            return

        # 추천값 계산 (특징은 이미 일부 캐시됨 — 동기 호출)
        sug = None
        if self._scan is not None:
            try:
                from ..similarity import threshold as _thr
                sug = _thr.suggest_threshold(self._scan)
            except Exception as _e:
                print(f"[임계치 추천] suggest_threshold 오류: {_e}")

        if sug is not None:
            msg = (
                f"유사도 매칭 전 임계치를 설정해 주세요.\n\n"
                f"━━ 자동 분석 결과 ━━━━━━━━━━━━━━━━━━━━\n"
                f"  추천 임계치 :  {sug.suggested:.2f}\n"
                f"  현재 설정값 :  {self._input.threshold:.2f}\n\n"
                f"  같은 슬롯 점수  중앙값 {sug.same_median:.2f}"
                f"  /  최솟값 {sug.same_min:.2f}\n"
                f"  다른 슬롯 점수  중앙값 {sug.diff_median:.2f}"
                f"  /  최댓값 {sug.diff_max:.2f}\n"
                f"  분포 간 여유 :  {sug.margin:+.2f}\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"추천값 {sug.suggested:.2f} (으)로 진행하시겠습니까?\n"
                f"'아니오'를 누르면 임계치를 직접 입력합니다."
            )
            r = QMessageBox.question(
                self, "임계치 설정",
                msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if r == QMessageBox.StandardButton.Yes:
                self._apply_threshold(sug.suggested)
                return
            # No → 직접 입력으로 이어짐
        else:
            msg = (
                f"유사도 매칭 전 임계치를 확인해 주세요.\n\n"
                f"  현재 설정값 :  {self._input.threshold:.2f}\n\n"
                f"※ 슬롯이 2개 미만이거나 이미지 샘플이 부족해\n"
                f"  자동 추천을 계산할 수 없습니다.\n\n"
                f"현재 값 ({self._input.threshold:.2f}) 으로 진행하시겠습니까?\n"
                f"'아니오'를 누르면 임계치를 직접 입력합니다."
            )
            r = QMessageBox.question(
                self, "임계치 설정",
                msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if r == QMessageBox.StandardButton.Yes:
                return  # 현재 값 그대로 진행
            # No → 직접 입력으로 이어짐

        self._ask_manual_threshold()

    def _ask_manual_threshold(self) -> None:
        """임계치 직접 입력 대화상자 (QInputDialog.getDouble)."""
        from PyQt6.QtWidgets import QInputDialog
        if self._input is None:
            return
        val, ok = QInputDialog.getDouble(
            self,
            "임계치 직접 입력",
            (
                "유사도 임계치를 직접 입력하세요.\n\n"
                f"  범위  :  0.10 ~ 0.99\n"
                f"  권장  :  0.60 ~ 0.85\n"
                f"  현재  :  {self._input.threshold:.2f}\n\n"
                "값이 낮을수록 더 많은 사진이 매칭되고,\n"
                "값이 높을수록 엄격하게 매칭됩니다.\n"
                "'취소'를 누르면 현재 값이 유지됩니다."
            ),
            value=self._input.threshold,
            min=0.10,
            max=0.99,
            decimals=2,
        )
        if ok:
            self._apply_threshold(round(val, 2))

    def _apply_threshold(self, value: float) -> None:
        """임계치 적용 + 설정 파일 저장."""
        if self._input is None:
            return
        self._input.threshold = float(value)
        try:
            from ..utils import prefs as _prefs
            _prefs.patch(threshold=float(value))
        except Exception:
            pass

    # ==================================================================
    # 슬롯 단위 선별 — 새 흐름
    # ==================================================================
    def _enter_slot_select(self, idx: int) -> None:
        """슬롯 idx 의 이미지에 대해 썸네일 생성 후 SelectPage 진입."""
        assert self._scan is not None and self._input is not None

        if self._thumb_worker is not None and self._thumb_worker.isRunning():
            self._thumb_worker.stop()
            self._thumb_worker.wait(2000)

        slot_name = self._slot_queue[idx]
        slot = self._scan.slots[slot_name]
        lower = self._lower_machine_side() if self._is_cross() else "ref"
        queue: list[ImageItem] = list(
            slot.ref_images if lower == "ref" else slot.val_images
        )
        slot_label = f"슬롯 {idx + 1} / {self._total_slots}  [{slot_name}]"

        self._loading.show_overlay(f"썸네일 생성 중 ({slot_name}) …")
        QApplication.processEvents()

        self._thumb_worker = ThumbnailWorker(queue, also_mid=True, parent=self)
        self._thumb_worker.signals.finished.connect(
            lambda _i=idx, _q=queue, _l=slot_label:
                self._on_slot_thumb_ready(_i, _q, _l)
        )
        self._thumb_worker.start()

    def _on_slot_thumb_ready(self, idx: int,
                              queue: list[ImageItem], slot_label: str) -> None:
        self._loading.hide_overlay()
        self._select_page.load_state(
            queue=queue,
            targets={}, excluded={}, history=[],
            phase_label=slot_label,
        )
        self._show_page(self._select_page)
        self._autosave()

    def _finish_slot_selection(self) -> None:
        """모든 슬롯 선별이 끝났거나 사용자가 중단 선택 — 요약 → feature 계산."""
        total_selected = sum(len(v) for v in self._all_selected_targets.values())
        n_slots = len(self._all_selected_targets)

        if total_selected == 0:
            QMessageBox.warning(
                self, "선별 없음",
                "검증할 사진이 선택되지 않았습니다.\n처음부터 다시 시작해 주세요.",
            )
            self._show_page(self._setup_page)
            return

        if n_slots < 2:
            r = QMessageBox.warning(
                self, "슬롯 부족 경고",
                f"현재 선별된 슬롯이 {n_slots}개입니다.\n\n"
                f"【유사도 임계치 자동 추천이 불가합니다】\n"
                f"임계치 추천은 '같은 슬롯 쌍'과 '다른 슬롯 쌍'의 점수 분포를\n"
                f"비교해 최적값을 계산합니다.\n"
                f"슬롯이 1개뿐이면 '다른 슬롯 쌍' 측정이 불가능하므로\n"
                f"추천 기능이 작동하지 않습니다.\n\n"
                f"임계치를 수동으로 설정하지 않으면 기본값({self._input.threshold:.2f})이\n"
                f"사용되어 매칭 정확도가 낮아질 수 있습니다.\n\n"
                f"그래도 계속 진행하시겠습니까?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if r != QMessageBox.StandardButton.Yes:
                self._show_page(self._setup_page)
                return

        r = QMessageBox.question(
            self, "선별 완료",
            f"총 {n_slots}개 슬롯, {total_selected}장 선택 완료.\n\n"
            f"이미지 매칭 단계로 진행하시겠습니까?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if r != QMessageBox.StandardButton.Yes:
            self._show_page(self._setup_page)
            return

        self._stage2_slot_queue = sorted(self._all_selected_targets.keys())
        self._stage2_slot_idx = 0
        self._enter_stage2_slot(0)

    # ==================================================================
    # Phase 식별 helpers
    # ==================================================================
    def _is_cross(self) -> bool:
        return self._input is not None and self._input.mode == "cross"

    def _lower_machine_side(self) -> str:
        """교차검증에서 '낮은 호기' 가 ref 인지 val 인지 추정 ('ref'/'val')."""
        if self._input is None:
            return "ref"
        # 호기명에서 숫자만 뽑아서 비교 → 실패하면 ref 우선
        def num(s: str) -> int:
            digits = "".join(ch for ch in s if ch.isdigit())
            return int(digits) if digits else 9999
        return "ref" if num(self._input.ref_machine) <= num(self._input.val_machine) else "val"

    # ==================================================================
    # Stage 1 — Phase A
    # ==================================================================
    def _enter_stage1_phase_a(self) -> None:
        assert self._scan is not None and self._input is not None
        # 낮은 호기 쪽이 Phase A 의 기준
        lower = self._lower_machine_side() if self._is_cross() else "ref"
        slots = [self._scan.slots[n] for n in self._scan.common_slot_names]
        # Phase A 의 queue: 낮은 호기 쪽 사진 전부 (Slot 명 / 파일명 오름차순)
        queue_full: list[ImageItem] = []
        for slot in sorted(slots, key=lambda s: s.name):
            queue_full.extend(slot.ref_images if lower == "ref" else slot.val_images)

        # 같은 슬롯 안 거의 동일한 사진은 그룹으로 묶어 대표만 큐에 (#15)
        grouping = self._make_groups(queue_full)
        queue = grouping.representatives if grouping else queue_full

        phase_lab = (
            i18n.KO.PHASE_A_SELECT if self._is_cross()
            else i18n.KO.STAGE1_TITLE
        )
        self._select_page.load_state(
            queue=queue,
            targets={}, excluded={}, history=[],
            phase_label=phase_lab,
            groups=grouping,
        )
        self._show_page(self._select_page)
        self._phase = PHASE_A_SELECT
        self._autosave()

    def _on_select_finished(self) -> None:
        if self._phase == PHASE_A_SELECT:
            # 현재 슬롯에서 선택된 항목 수집
            st = self._select_page.get_state()
            if st:
                for slot_name, items in st.targets.items():
                    if items:
                        self._all_selected_targets.setdefault(
                            slot_name, []
                        ).extend(items)

            # 다음 슬롯이 남아 있으면 사용자에게 물어봄
            next_idx = self._current_slot_idx + 1
            if next_idx < self._total_slots:
                current_slot = self._slot_queue[self._current_slot_idx]
                next_slot = self._slot_queue[next_idx]
                r = QMessageBox.question(
                    self, "슬롯 완료",
                    f"슬롯 '{current_slot}' 완료.\n\n"
                    f"다음 슬롯 '{next_slot}'으로 진행할까요?\n"
                    f"'아니오'를 누르면 현재까지 선택된 슬롯으로만 매칭합니다.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes,
                )
                if r == QMessageBox.StandardButton.Yes:
                    self._current_slot_idx = next_idx
                    self._enter_slot_select(next_idx)
                    return

            # 모든 슬롯 완료 or 사용자가 여기서 중단
            self._finish_slot_selection()

        elif self._phase == PHASE_B_SELECT:
            self._stage1_b_snapshot = {
                "targets": self._collect_panel(self._select_page.get_state().targets),
                "excluded": self._collect_panel(self._select_page.get_state().excluded),
            }
            QMessageBox.information(
                self, i18n.KO.INFO_PHASE_TRANSITION_TITLE,
                i18n.KO.INFO_PHASE_B_TO_MATCH,
            )
            self._enter_stage2_phase_b()

    @staticmethod
    def _collect_panel(
        panel: dict[str, list[ImageItem]]
    ) -> dict[str, list[ImageItem]]:
        return {k: list(v) for k, v in panel.items() if v}

    # ==================================================================
    # Stage 2 — 슬롯별 feature 추출 + 일괄 유사도 계산
    # ==================================================================
    def _enter_stage2_slot(self, idx: int) -> None:
        """슬롯 idx 의 feature 추출 → 완료 후 일괄 유사도 계산."""
        assert self._scan is not None and self._input is not None
        slot_name = self._stage2_slot_queue[idx]
        slot = self._scan.slots[slot_name]
        lower = self._lower_machine_side() if self._is_cross() else "ref"
        higher = "val" if lower == "ref" else "ref"

        selected = self._all_selected_targets.get(slot_name, [])
        higher_imgs: list[ImageItem] = (
            slot.val_images if higher == "val" else slot.ref_images
        )
        all_items = list(selected) + list(higher_imgs)
        total = len(all_items)
        n_slots = len(self._stage2_slot_queue)
        self._loading.show_overlay(
            f"슬롯 {idx + 1}/{n_slots} [{slot_name}] 이미지 처리 중 … (0/{total})"
        )

        if self._feature_worker is not None and self._feature_worker.isRunning():
            self._feature_worker.stop()
            self._feature_worker.wait(1000)

        self._feature_worker = FeatureWorker(all_items, parent=self)
        self._feature_worker.signals.progress.connect(
            lambda done, tot, _p, _i=idx, _sn=slot_name, _n=n_slots:
                self._loading.set_progress(
                    done, tot,
                    f"슬롯 {_i + 1}/{_n} [{_sn}] 이미지 처리 중 … ({done}/{tot})",
                )
        )
        self._feature_worker.signals.finished.connect(
            lambda _i=idx: self._on_stage2_slot_feature_ready(_i)
        )
        self._feature_worker.start()

    def _on_stage2_slot_feature_ready(self, idx: int) -> None:
        """feature 추출 완료 → 일괄 유사도 계산 시작."""
        assert self._scan is not None and self._input is not None
        slot_name = self._stage2_slot_queue[idx]
        slot = self._scan.slots[slot_name]
        lower = self._lower_machine_side() if self._is_cross() else "ref"
        higher = "val" if lower == "ref" else "ref"

        selected = self._all_selected_targets.get(slot_name, [])
        higher_imgs: list[ImageItem] = (
            slot.val_images if higher == "val" else slot.ref_images
        )
        n_slots = len(self._stage2_slot_queue)
        n_ref = len(selected)

        # 첫 번째 슬롯 진입 전 항상 임계치 확인 대화상자 표시
        # (오버레이를 숨겨야 대화상자가 전면에 정상 노출됨)
        if idx == 0:
            self._loading.hide_overlay()
            self._confirm_threshold_before_stage2()

        self._loading.show_overlay(
            f"슬롯 {idx + 1}/{n_slots} [{slot_name}] 유사도 계산 중 … (0/{n_ref})"
        )
        self._loading.set_progress(
            0, n_ref,
            f"슬롯 {idx + 1}/{n_slots} [{slot_name}] 유사도 계산 중 … (0/{n_ref})",
        )

        if self._batch_worker is not None and self._batch_worker.isRunning():
            self._batch_worker.stop()
            self._batch_worker.wait(1000)

        self._batch_worker = BatchMatcherWorker(
            selected, higher_imgs,
            threshold=self._input.threshold,
            parent=self,
        )
        self._batch_worker.signals.progress.connect(
            lambda done, tot, _i=idx, _sn=slot_name, _n=n_slots:
                self._loading.set_progress(
                    done, tot,
                    f"슬롯 {_i + 1}/{_n} [{_sn}] 유사도 계산 중 … ({done}/{tot})",
                )
        )
        self._batch_worker.signals.done.connect(
            lambda precomputed, _i=idx, _sn=slot_name, _hi=list(higher_imgs):
                self._on_stage2_batch_ready(_i, _sn, _hi, precomputed)
        )
        self._batch_worker.signals.failed.connect(
            lambda msg: self._loading.set_progress(0, 0, msg)
        )
        self._batch_worker.start()

    def _on_stage2_batch_ready(self, idx: int, slot_name: str,
                                higher_imgs: list[ImageItem],
                                precomputed: dict) -> None:
        """유사도 계산 완료 → MatchPage 로드."""
        self._loading.hide_overlay()
        assert self._input is not None

        selected = self._all_selected_targets.get(slot_name, [])
        n_slots = len(self._stage2_slot_queue)
        direction = "A→B"
        phase_lab = (
            i18n.KO.PHASE_A_MATCH if self._is_cross()
            else f"슬롯 {idx + 1}/{n_slots} [{slot_name}]"
        )
        self._match_page.load_state(
            queue=list(selected),
            val_pool_by_slot={slot_name: list(higher_imgs)},
            threshold=self._input.threshold,
            phase_label=phase_lab,
            direction=direction,
            session_id=self._session_id,
            model_name=self._active_model_name(),
            precomputed=precomputed,
        )
        self._show_page(self._match_page)
        self._phase = PHASE_A_MATCH
        self._autosave()

    def _on_match_confirmed(self, match: MatchResult) -> None:
        if self._phase == PHASE_A_MATCH:
            self._matches_a.append(match)
            # Phase A 에서 매칭된 검증 쪽 파일을 기록 (Phase B 에서 자동 제외)
            self._matched_val_keys_in_a.add(self._val_key(match))
        elif self._phase == PHASE_B_MATCH:
            self._matches_b.append(match)
        self._schedule_autosave()

    @staticmethod
    def _val_key(match: MatchResult) -> str:
        return f"{match.slot}::{match.val_path.name}"

    def _on_match_finished(self) -> None:
        if self._phase == PHASE_A_MATCH:
            st = self._match_page.get_state()
            if st is not None:
                for slot, items in st.no_match.items():
                    self._skipped_a[slot].extend(items)

            # 다음 슬롯이 있으면 계속
            next_idx = self._stage2_slot_idx + 1
            if next_idx < len(self._stage2_slot_queue):
                self._stage2_slot_idx = next_idx
                self._enter_stage2_slot(next_idx)
                return

            # 모든 슬롯 완료
            if self._is_cross():
                QMessageBox.information(
                    self, i18n.KO.INFO_PHASE_TRANSITION_TITLE,
                    i18n.KO.INFO_PHASE_A_TO_B,
                )
                self._enter_stage1_phase_b()
            else:
                self._finish_session()

        elif self._phase == PHASE_B_MATCH:
            st = self._match_page.get_state()
            if st is not None:
                for slot, items in st.no_match.items():
                    self._skipped_b[slot].extend(items)
            self._finish_session()

    # ==================================================================
    # Stage 1 — Phase B (reverse direction)
    # ==================================================================
    def _enter_stage1_phase_b(self) -> None:
        assert self._scan is not None and self._input is not None
        lower = self._lower_machine_side()
        higher = "val" if lower == "ref" else "ref"

        # 큐 = Phase A 에서 선택된 슬롯의 higher-side 사진
        # (이미 Phase A 에서 매칭된 항목은 "already" 섹션으로 분리)
        selected_slots = sorted(self._all_selected_targets.keys())
        queue: list[ImageItem] = []
        already_by_slot: dict[str, list[ImageItem]] = defaultdict(list)
        for name in selected_slots:
            slot = self._scan.slots[name]
            higher_imgs = slot.val_images if higher == "val" else slot.ref_images
            for it in higher_imgs:
                if f"{name}::{it.path.name}" in self._matched_val_keys_in_a:
                    already_by_slot[name].append(it)
                else:
                    queue.append(it)

        # 썸네일 생성 후 SelectPage 진입
        all_phase_b = queue + [it for its in already_by_slot.values() for it in its]
        self._loading.show_overlay("Phase B 썸네일 생성 중 …")
        QApplication.processEvents()
        self._thumb_worker = ThumbnailWorker(all_phase_b, also_mid=False, parent=self)
        self._thumb_worker.signals.finished.connect(
            lambda _q=queue, _ab=already_by_slot:
                self._on_phase_b_thumb_ready(_q, _ab)
        )
        self._thumb_worker.start()

    def _on_phase_b_thumb_ready(
        self,
        queue: list[ImageItem],
        already_by_slot: dict[str, list[ImageItem]],
    ) -> None:
        self._loading.hide_overlay()
        self._select_page.load_state(
            queue=queue,
            targets={}, excluded={}, history=[],
            phase_label=i18n.KO.PHASE_B_SELECT,
            phase_b_already_matched=dict(already_by_slot),
        )
        self._show_page(self._select_page)
        self._phase = PHASE_B_SELECT
        self._autosave()

    # ==================================================================
    # Stage 2 — Phase B
    # ==================================================================
    def _enter_stage2_phase_b(self) -> None:
        assert self._scan is not None and self._input is not None
        lower = self._lower_machine_side()
        higher = "val" if lower == "ref" else "ref"
        targets = self._stage1_b_snapshot["targets"] if self._stage1_b_snapshot else {}

        queue: list[ImageItem] = []
        for slot in sorted(targets.keys()):
            queue.extend(targets[slot])

        # 매칭 대상 풀 = 같은 Slot 의 낮은 호기 사진들 (반대 방향)
        pool: dict[str, list[ImageItem]] = {}
        for name in self._scan.common_slot_names:
            slot = self._scan.slots[name]
            pool[name] = slot.ref_images if lower == "ref" else slot.val_images

        direction = "B→A"
        self._match_page.load_state(
            queue=queue,
            val_pool_by_slot=pool,
            threshold=self._input.threshold,
            phase_label=i18n.KO.PHASE_B_MATCH,
            direction=direction,
            session_id=self._session_id,
            model_name=self._active_model_name(),
        )
        self._show_page(self._match_page)
        self._phase = PHASE_B_MATCH
        self._autosave()

    # ==================================================================
    # Result
    # ==================================================================
    def _finish_session(self) -> None:
        assert self._scan is not None and self._input is not None
        merged = self._merge_matches()
        miss_fast, miss_slow = self._compute_miss_lists()

        result = FinalResult(
            mode=self._input.mode,
            ref_machine=self._input.ref_machine,
            val_machine=self._input.val_machine,
            matches=merged,
            miss_fast=miss_fast,
            miss_slow=miss_slow,
            slot_only_ref=list(self._scan.ref_only),
            slot_only_val=list(self._scan.val_only),
        )
        # 결과 페이지에는 ‘이미 복사해둔 작업 파일’ 과 ‘템플릿 원본’ 둘 다 전달.
        self._result_page.show_result(
            result,
            template_path=self._template_used,
            target_path=self._working_xlsx,
        )
        QMessageBox.information(self, i18n.KO.APP_TITLE, i18n.KO.INFO_ALL_DONE)
        self._show_page(self._result_page)
        self._phase = PHASE_NONE
        session_mod.clear()

    # ------------------------------------------------------------------
    # 양식 → 결과 파일 복사
    # ------------------------------------------------------------------
    def _prepare_working_file(self, inp: SetupInput) -> None:
        """`양식/양식.xlsx` 를 결과 폴더로 복사해서 작업 파일을 만든다.

        결과 파일 이름: ``AOI {val} 검증 ({ref} 기준).xlsx``.
        이미 존재하면 타임스탬프를 붙여 충돌을 피한다.
        """
        template = paths.template_path()
        if not template.exists():
            QMessageBox.information(
                self, i18n.KO.TEMPLATE_NOT_FOUND_TITLE,
                i18n.KO.TEMPLATE_NOT_FOUND_BODY.format(path=str(template)),
            )
            self._template_used = None
        else:
            self._template_used = template

        # 파일 이름
        dst_name = i18n.KO.RESULT_FILE_TITLE_FMT.format(
            val=inp.val_machine, ref=inp.ref_machine,
        )
        dst = paths.results_dir() / dst_name
        if dst.exists():
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            dst = dst.with_name(dst.stem + f"_{ts}" + dst.suffix)

        # 템플릿이 있으면 복사, 없으면 빈 파일 자리 표시만 (저장 시점에 생성)
        try:
            if self._template_used is not None:
                shutil.copyfile(str(self._template_used), str(dst))
        except Exception:
            # 복사 실패 시에도 경로는 보존 — 저장 시점에 새 워크북 생성
            pass

        self._working_xlsx = dst

    def _merge_matches(self) -> list[MatchResult]:
        if not self._is_cross():
            return list(self._matches_a)

        # 키 = (Slot, 낮은호기 파일명, 높은호기 파일명).
        # Phase A: ref_path = 낮은호기 / val_path = 높은호기
        # Phase B: ref_path = 높은호기 / val_path = 낮은호기  ← 이걸 정규화한다.
        lower = self._lower_machine_side()
        higher = "val" if lower == "ref" else "ref"

        def _norm(m: MatchResult) -> tuple[str, str, str, MatchResult]:
            # Phase A 는 그대로, Phase B 는 ref/val 을 뒤집어 정규화
            if m.direction == "A→B":
                low_path = m.ref_path
                high_path = m.val_path
            else:
                low_path = m.val_path
                high_path = m.ref_path
            norm = MatchResult(
                slot=m.slot,
                ref_path=low_path,
                val_path=high_path,
                score=m.score,
                direction=m.direction,
            )
            return (m.slot, low_path.name, high_path.name, norm)

        bag: dict[tuple[str, str, str], MatchResult] = {}
        for m in self._matches_a + self._matches_b:
            k0, k1, k2, norm = _norm(m)
            key = (k0, k1, k2)
            if key in bag:
                bag[key].direction = "양방향"
            else:
                bag[key] = norm
        return sorted(bag.values(), key=lambda x: (x.slot, x.ref_path.name.lower()))

    def _compute_miss_lists(self) -> tuple[list[MissEntry], list[MissEntry]]:
        if not self._is_cross():
            return [], []
        # 빠른(낮은) 호기 미탐 = Phase A 에서 skip 된 사진들
        miss_fast: list[MissEntry] = []
        for slot, items in self._skipped_a.items():
            for it in items:
                miss_fast.append(MissEntry(
                    slot=slot, side="ref", path=it.path,
                    note="Phase A 매칭 실패",
                ))
        # 느린(높은) 호기 미탐 = Phase B 에서 skip 된 사진들
        miss_slow: list[MissEntry] = []
        for slot, items in self._skipped_b.items():
            for it in items:
                miss_slow.append(MissEntry(
                    slot=slot, side="val", path=it.path,
                    note="Phase B 매칭 실패",
                ))
        return miss_fast, miss_slow

    def _new_session(self) -> None:
        session_mod.clear()
        self._matches_a.clear()
        self._matches_b.clear()
        self._skipped_a.clear()
        self._skipped_b.clear()
        self._matched_val_keys_in_a.clear()
        self._stage1_a_snapshot = None
        self._stage1_b_snapshot = None
        self._slot_queue = []
        self._total_slots = 0
        self._current_slot_idx = 0
        self._all_selected_targets.clear()
        self._stage2_slot_queue = []
        self._stage2_slot_idx = 0
        self._phase = PHASE_NONE
        self._refresh_models_safe()
        self._show_page(self._setup_page)

    # ==================================================================
    # Page switching
    # ==================================================================
    def _show_page(self, w: QWidget) -> None:
        self._stack.setCurrentWidget(w)

    # ==================================================================
    # Auto-save
    # ==================================================================
    def _schedule_autosave(self) -> None:
        # 결정이 있을 때마다 즉시 저장한다 (가벼움)
        self._autosave()

    def _autosave(self) -> None:
        if self._input is None:
            return
        # Stage 1 / Stage 2 의 현재 상태도 함께 직렬화 (#19)
        decisions: dict[str, str] = {}
        no_match_keys: list[str] = []
        skipped_keys: list[str] = []
        matches_dump: list[dict] = []
        st1 = self._select_page.get_state()
        if st1 is not None:
            for slot, items in st1.targets.items():
                for it in items:
                    decisions[it.key] = "verify"
            for slot, items in st1.excluded.items():
                for it in items:
                    decisions[it.key] = "exclude"
        st2 = self._match_page.get_state()
        if st2 is not None:
            for m in st2.matches:
                matches_dump.append({
                    "slot": m.slot,
                    "ref_path": str(m.ref_path),
                    "val_path": str(m.val_path),
                    "score": float(m.score),
                    "direction": str(m.direction),
                })
            for slot, items in st2.skipped.items():
                for it in items:
                    skipped_keys.append(it.key)
            for slot, items in st2.no_match.items():
                for it in items:
                    no_match_keys.append(it.key)

        state = session_mod.SessionState(
            mode=self._input.mode,
            ref_root=str(self._input.ref_root),
            val_root=str(self._input.val_root),
            ref_machine=self._input.ref_machine,
            val_machine=self._input.val_machine,
            threshold=self._input.threshold,
            session_id=self._session_id,
            stage=self._phase or "setup",
            phase=("B" if self._phase in (PHASE_B_SELECT, PHASE_B_MATCH) else "A"),
            decisions=decisions,
            matches=matches_dump,
            skipped=skipped_keys,
            no_match=no_match_keys,
            phase_a_matched_val_keys=sorted(self._matched_val_keys_in_a),
            phase_a_matches=[{
                "slot": m.slot,
                "ref_path": str(m.ref_path),
                "val_path": str(m.val_path),
                "score": float(m.score),
                "direction": str(m.direction),
            } for m in self._matches_a],
        )
        try:
            session_mod.save(state)
        except Exception:
            pass

    # ==================================================================
    # Cleanup
    # ==================================================================
    # ==================================================================
    # 화면 크기 프리셋 (#2)
    # ==================================================================
    def _build_view_menu(self) -> None:
        from PyQt6.QtGui import QAction
        menu_bar = self.menuBar()
        view_menu = menu_bar.addMenu(i18n.KO.MENU_VIEW)
        for label, w, h in i18n.KO.WINDOW_PRESETS:
            act = QAction(label, self)
            act.triggered.connect(
                lambda _checked=False, name=label: self._apply_window_preset(name)
            )
            view_menu.addAction(act)

    def _apply_window_preset(self, name: str, *, persist: bool = True) -> None:
        for label, w, h in i18n.KO.WINDOW_PRESETS:
            if label != name:
                continue
            if w == 0 or h == 0:
                self.showMaximized()
            else:
                # 최대화 상태였다면 풀고 새 크기 적용
                if self.isMaximized():
                    self.showNormal()
                self.resize(w, h)
            if persist:
                try:
                    self._prefs.patch(window_preset=name)
                except Exception:
                    pass
            return

    def closeEvent(self, event):  # noqa: N802
        if self._thumb_worker is not None and self._thumb_worker.isRunning():
            self._thumb_worker.stop()
            self._thumb_worker.wait(1000)
        if self._feature_worker is not None and self._feature_worker.isRunning():
            self._feature_worker.stop()
            self._feature_worker.wait(1000)
        if self._batch_worker is not None and self._batch_worker.isRunning():
            self._batch_worker.stop()
            self._batch_worker.wait(1000)
        try:
            self._setup_page.stop_training()
        except Exception:
            pass
        super().closeEvent(event)
