"""패널 선택 모드 다이얼로그 — 전체 항목 체크 + 일괄 액션."""

from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QScrollArea,
                              QVBoxLayout, QWidget)

from ... import i18n
from ...models.slot import ImageItem
from .neon_button import NeonButton
from .slot_section import SlotSection
from .thumb_grid import ThumbEntry


class PanelSelectDialog(QDialog):
    """패널의 모든 항목을 한 화면에서 선택해 일괄 액션을 적용."""

    action_applied = pyqtSignal(str, list)   # (action_id, [ImageItem])

    def __init__(self,
                 title: str,
                 data: dict[str, list[ImageItem]],
                 actions: list[tuple[str, str, str]],
                 *,
                 parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(760, 540)
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowCloseButtonHint
        )

        self._sections: dict[str, SlotSection] = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        # 상단: 타이틀 + 전체 선택/해제
        top = QHBoxLayout()
        ttl = QLabel(title, self)
        ttl.setStyleSheet(
            "font-weight: 700; color: #00D4FF; font-size: 14px;"
        )
        top.addWidget(ttl)
        top.addStretch(1)
        btn_all = NeonButton(i18n.KO.BTN_SELECT_ALL, role="ghost")
        btn_none = NeonButton(i18n.KO.BTN_DESELECT_ALL, role="ghost")
        btn_all.clicked.connect(self._select_all)
        btn_none.clicked.connect(self._deselect_all)
        top.addWidget(btn_all)
        top.addWidget(btn_none)
        root.addLayout(top)

        # 스크롤 영역 — 슬롯별 그리드 (truncate=False, select_mode=True)
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        host = QWidget()
        host_lay = QVBoxLayout(host)
        host_lay.setContentsMargins(4, 4, 4, 4)
        host_lay.setSpacing(10)
        scroll.setWidget(host)

        for slot in sorted(data.keys()):
            items = data[slot]
            if not items:
                continue
            sec = SlotSection(slot, columns=4, select_mode=True, parent=host)
            # truncate=True 가 기본이지만 dialog 에서는 전체 노출
            sec.grid._truncate = False
            sec.set_entries([ThumbEntry(item=it) for it in items])
            self._sections[slot] = sec
            host_lay.addWidget(sec)
        host_lay.addStretch(1)
        root.addWidget(scroll, stretch=1)

        # 하단: 패널 액션 버튼 + 닫기
        bot = QHBoxLayout()
        for action_id, label, role in actions:
            btn = NeonButton(label, role=role)
            btn.clicked.connect(
                lambda _checked=False, a=action_id: self._apply_action(a)
            )
            bot.addWidget(btn)
        bot.addStretch(1)
        close_btn = NeonButton(i18n.KO.BTN_CANCEL, role="ghost")
        close_btn.clicked.connect(self.reject)
        bot.addWidget(close_btn)
        root.addLayout(bot)

    # ------------------------------------------------------------------
    def _select_all(self) -> None:
        for sec in self._sections.values():
            sec.grid.select_all()

    def _deselect_all(self) -> None:
        for sec in self._sections.values():
            sec.grid.deselect_all()

    def _apply_action(self, action_id: str) -> None:
        items: list[ImageItem] = []
        for sec in self._sections.values():
            for ent in sec.grid.selected():
                items.append(ent.item)
        if not items:
            return
        self.action_applied.emit(action_id, items)
        self.accept()
