"""패널 선택 모드 다이얼로그 — 전체 항목 체크 + 일괄 액션.

슬롯 하나씩 QTimer 체인으로 위젯 생성 → 이벤트 루프를 살려두어
창이 "응답없음" 으로 표시되지 않고 로딩 중 화면이 유지된다.
"""

from __future__ import annotations

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QScrollArea,
                              QVBoxLayout, QWidget)

from ... import i18n
from ...models.slot import ImageItem
from .neon_button import NeonButton
from .slot_section import SlotSection
from .thumb_grid import ThumbEntry


class PanelSelectDialog(QDialog):
    """패널의 모든 항목을 한 화면에서 선택해 일괄 액션을 적용."""

    action_applied = pyqtSignal(str, list)   # (action_id, [ImageItem])

    def __init__(self,
                 title: str,
                 data: dict[str, list[ImageItem]],
                 actions: list[tuple[str, str, str]],
                 *,
                 parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(760, 540)
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowCloseButtonHint
        )

        self._data = data
        self._actions_spec = actions
        self._sections: dict[str, SlotSection] = {}
        self._action_buttons: list[NeonButton] = []
        self._slots_to_build: list[str] = []
        self._total_slots: int = 0

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        # ── 상단: 타이틀 + 전체 선택/해제 ──────────────────────────────
        top = QHBoxLayout()
        ttl = QLabel(title, self)
        ttl.setStyleSheet("font-weight: 700; color: #00D4FF; font-size: 14px;")
        top.addWidget(ttl)
        top.addStretch(1)
        self._btn_all = NeonButton(i18n.KO.BTN_SELECT_ALL, role="ghost")
        self._btn_none = NeonButton(i18n.KO.BTN_DESELECT_ALL, role="ghost")
        self._btn_all.clicked.connect(self._select_all)
        self._btn_none.clicked.connect(self._deselect_all)
        self._btn_all.setEnabled(False)
        self._btn_none.setEnabled(False)
        top.addWidget(self._btn_all)
        top.addWidget(self._btn_none)
        root.addLayout(top)

        # ── 스크롤 영역 ─────────────────────────────────────────────────
        self._scroll = QScrollArea(self)
        self._scroll.setWidgetResizable(True)
        self._host = QWidget()
        self._host_lay = QVBoxLayout(self._host)
        self._host_lay.setContentsMargins(4, 4, 4, 4)
        self._host_lay.setSpacing(10)
        self._scroll.setWidget(self._host)

        # 로딩 안내 레이블
        self._loading_label = QLabel("이미지 로딩 중 … (0 / 0)", self._host)
        self._loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._loading_label.setStyleSheet(
            "color: #00D4FF; font-size: 16px; padding: 60px;"
        )
        self._host_lay.addWidget(self._loading_label)
        self._host_lay.addStretch(1)
        root.addWidget(self._scroll, stretch=1)

        # ── 하단: 액션 버튼 + 닫기 ──────────────────────────────────────
        bot = QHBoxLayout()
        for action_id, label, role in actions:
            btn = NeonButton(label, role=role)
            btn.setEnabled(False)
            btn.clicked.connect(
                lambda _checked=False, a=action_id: self._apply_action(a)
            )
            bot.addWidget(btn)
            self._action_buttons.append(btn)
        bot.addStretch(1)
        close_btn = NeonButton(i18n.KO.BTN_CANCEL, role="ghost")
        close_btn.clicked.connect(self.reject)
        bot.addWidget(close_btn)
        root.addLayout(bot)

        # 다이얼로그 표시 후 슬롯 순차 빌드 시작
        QTimer.singleShot(0, self._start_build)

    # ------------------------------------------------------------------
    def _start_build(self) -> None:
        """빌드 큐 초기화 후 첫 번째 슬롯 빌드 시작."""
        self._slots_to_build = sorted(self._data.keys())
        self._total_slots = len(self._slots_to_build)
        # stretch 제거 후 로딩 레이블만 남기기
        while self._host_lay.count() > 1:
            item = self._host_lay.takeAt(1)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._build_next_slot()

    def _build_next_slot(self) -> None:
        """슬롯 하나 생성 → 이벤트 루프 반환 → 다음 슬롯 예약."""
        if not self._slots_to_build:
            self._on_build_complete()
            return

        done = self._total_slots - len(self._slots_to_build)
        self._loading_label.setText(
            f"이미지 로딩 중 … ({done} / {self._total_slots})"
        )

        slot = self._slots_to_build.pop(0)
        items = self._data.get(slot, [])
        if items:
            sec = SlotSection(slot, columns=4, select_mode=True,
                              parent=self._host)
            sec.grid._truncate = False
            sec.set_entries([ThumbEntry(item=it) for it in items])
            self._sections[slot] = sec
            self._host_lay.addWidget(sec)

        # 이벤트 루프에 제어권 반환 후 다음 슬롯 예약
        QTimer.singleShot(0, self._build_next_slot)

    def _on_build_complete(self) -> None:
        """전체 슬롯 빌드 완료 → 로딩 레이블 숨기고 버튼 활성화."""
        self._loading_label.hide()
        self._host_lay.addStretch(1)
        self._btn_all.setEnabled(True)
        self._btn_none.setEnabled(True)
        for btn in self._action_buttons:
            btn.setEnabled(True)

    # ------------------------------------------------------------------
    def _select_all(self) -> None:
        for sec in self._sections.values():
            sec.grid.select_all()

    def _deselect_all(self) -> None:
        for sec in self._sections.values():
            sec.grid.deselect_all()

    def _apply_action(self, action_id: str) -> None:
        items: list[ImageItem] = []
        for sec in self._sections.values():
            for ent in sec.grid.selected():
                items.append(ent.item)
        if not items:
            return
        self.action_applied.emit(action_id, items)
        self.accept()
