"""특징 추출(=유사도 비교에 필요한 모든 디스크립터) 워커."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..models.slot import ImageItem
from ..similarity import pipeline as sim


class FeatureSignals(QObject):
    progress = pyqtSignal(int, int, str)
    finished = pyqtSignal()
    failed = pyqtSignal(str)


class FeatureWorker(QThread):
    """이미지 목록을 받아 Feature 캐시를 채워두는 QThread."""

    def __init__(self,
                 items: Iterable[ImageItem],
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._items: list[ImageItem] = list(items)
        self._stop = False
        self.signals = FeatureSignals()

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:        # type: ignore[override]
        total = len(self._items)
        if total == 0:
            self.signals.finished.emit()
            return

        for idx, item in enumerate(self._items, start=1):
            if self._stop:
                break
            try:
                sim.extract(item.path)
            except Exception as exc:
                self.signals.failed.emit(f"{item.path}: {exc}")
            self.signals.progress.emit(idx, total, str(item.path))

        self.signals.finished.emit()


class PreloadSignals(QObject):
    progress = pyqtSignal(int, int)   # done, total
    finished = pyqtSignal()


class FeaturePreloadWorker(QThread):
    """Stage 2 진입 시 검증 폴더 전체 Feature 를 메모리에 선제 로드하는 워커.

    sim.extract() 가 자동으로 _mem_cache 에 저장하므로, 이후 MatcherWorker
    는 디스크 I/O 없이 메모리에서 즉시 Feature 를 가져온다.
    """

    def __init__(self,
                 items: Iterable[ImageItem],
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._items: list[ImageItem] = list(items)
        self._stop = False
        self.signals = PreloadSignals()

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:        # type: ignore[override]
        total = len(self._items)
        for idx, item in enumerate(self._items, start=1):
            if self._stop:
                break
            try:
                sim.extract(item.path)
            except Exception:
                pass
            self.signals.progress.emit(idx, total)
        self.signals.finished.emit()
