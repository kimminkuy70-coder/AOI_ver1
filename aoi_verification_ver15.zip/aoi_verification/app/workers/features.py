"""특징 추출(=유사도 비교에 필요한 모든 디스크립터) 워커.

ThreadPoolExecutor(max_workers=4) 로 병렬 추출.
numpy / cv2 / torch 는 GIL 을 해제하므로 실제 병렬 효과가 있음.
"""

from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..models.slot import ImageItem
from ..similarity import pipeline as sim

_MAX_WORKERS = 4


class FeatureSignals(QObject):
    progress = pyqtSignal(int, int, str)
    finished = pyqtSignal()
    failed = pyqtSignal(str)


class FeatureWorker(QThread):
    """이미지 목록을 받아 Feature 캐시를 채워두는 QThread.

    내부적으로 ThreadPoolExecutor(_MAX_WORKERS) 를 사용해 병렬 추출.
    """

    def __init__(self,
                 items: Iterable[ImageItem],
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._items: list[ImageItem] = list(items)
        self._stop = False
        self._lock = threading.Lock()
        self._done_count = 0
        self.signals = FeatureSignals()

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:        # type: ignore[override]
        total = len(self._items)
        if total == 0:
            self.signals.finished.emit()
            return

        self._done_count = 0

        def _extract_one(item: ImageItem) -> ImageItem:
            """단일 이미지 추출 — 스레드풀 워커에서 실행."""
            if self._stop:
                return item
            try:
                sim.extract(item.path)
            except Exception as exc:
                self.signals.failed.emit(f"{item.path}: {exc}")
            return item

        with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as pool:
            futures = {pool.submit(_extract_one, item): item
                       for item in self._items}
            for future in as_completed(futures):
                if self._stop:
                    break
                item = futures[future]
                with self._lock:
                    self._done_count += 1
                    done = self._done_count
                self.signals.progress.emit(done, total, str(item.path))

        self.signals.finished.emit()
