"""임계치 자동 추천 계산 워커 — 메인 스레드 블로킹 방지."""

from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..models.slot import ScanResult
from ..similarity.threshold import ThresholdSuggestion


class ThresholdSignals(QObject):
    finished = pyqtSignal(object)   # ThresholdSuggestion | None
    failed = pyqtSignal(str)


class ThresholdWorker(QThread):
    """suggest_threshold() 를 백그라운드에서 실행하는 QThread.

    완료 시 finished(suggestion) 시그널을 emit.
    suggestion 이 None 이면 추천 불가 (슬롯 부족 / 샘플 부족).
    """

    def __init__(self,
                 scan: ScanResult,
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._scan = scan
        self.signals = ThresholdSignals()

    def run(self) -> None:  # type: ignore[override]
        try:
            from ..similarity import threshold as _thr
            result: Optional[ThresholdSuggestion] = _thr.suggest_threshold(self._scan)
        except Exception as exc:
            print(f"[임계치 추천] ThresholdWorker 오류: {exc}")
            result = None
        self.signals.finished.emit(result)
