"""ref 전체 × val 전체 유사도를 한 번에 사전 계산하는 워커.

feature 는 이미 디스크 캐시에 있다고 가정 (FeatureWorker 완료 후 호출).
결과는 dict[Path, list[Candidate]] 로 시그널 emit.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

from PyQt6.QtCore import QObject, QThread, pyqtSignal

from ..models.slot import ImageItem
from ..similarity import pipeline as sim
from .matcher import Candidate


class BatchMatcherSignals(QObject):
    progress = pyqtSignal(int, int)   # done_ref, total_ref
    done = pyqtSignal(object)         # dict[Path, list[Candidate]]
    failed = pyqtSignal(str)


class BatchMatcherWorker(QThread):
    """ref 목록 × val 목록 전체 유사도 사전 계산."""

    def __init__(self,
                 ref_items: Iterable[ImageItem],
                 val_items: Iterable[ImageItem],
                 threshold: float,
                 parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._refs: list[ImageItem] = list(ref_items)
        self._vals: list[ImageItem] = list(val_items)
        self._threshold = threshold
        self._stop = False
        self.signals = BatchMatcherSignals()

    def stop(self) -> None:
        self._stop = True

    def run(self) -> None:  # type: ignore[override]
        total = len(self._refs)
        result: dict[Path, list[Candidate]] = {}

        for idx, ref in enumerate(self._refs, start=1):
            if self._stop:
                break
            try:
                ref_feat = sim.extract(ref.path)
            except Exception as exc:
                self.signals.failed.emit(f"{ref.path}: {exc}")
                result[ref.path] = []
                self.signals.progress.emit(idx, total)
                continue

            candidates: list[Candidate] = []
            for val in self._vals:
                if self._stop:
                    break
                try:
                    val_feat = sim.extract(val.path)
                    s = sim.score(ref_feat, val_feat)
                    if s >= self._threshold:
                        candidates.append(Candidate(item=val, score=s))
                except Exception:
                    pass

            candidates.sort(key=lambda c: c.score, reverse=True)
            result[ref.path] = candidates
            self.signals.progress.emit(idx, total)

        self.signals.done.emit(result)
