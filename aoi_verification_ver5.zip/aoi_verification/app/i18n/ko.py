"""모든 사용자 노출 문자열(한국어)을 한 곳에 모아둔 모듈.

UI/로그/툴팁/오류 메시지 모두 이 모듈을 통해 참조합니다.
번역이나 일괄 수정 시 이 파일만 보면 됩니다.
"""

# ── 앱/메타 ────────────────────────────────────────────────────────────────
APP_TITLE = "AOI 검증"
APP_DEVELOPER = "임현택 (HyunTaek Lim)"
APP_AFFILIATION = "Bump 2 Dept. / AOI Engineer"

# ── 공통 버튼/액션 ─────────────────────────────────────────────────────────
BTN_OK = "확인"
BTN_CANCEL = "취소"
BTN_BACK = "뒤로"
BTN_NEXT = "다음"
BTN_START = "검증 시작"
BTN_BROWSE = "폴더 선택…"
BTN_VERIFY = "검증"
BTN_EXCLUDE = "제외"
BTN_UNDO = "되돌리기"
BTN_SKIP = "잠시 보류"
BTN_NO_MATCH = "매칭 없음 확정"
BTN_RETRY_SKIP = "보류 재시도"
BTN_SELECT_MODE = "선택 모드"
BTN_CANCEL_SELECT_MODE = "선택 해제"
BTN_REMOVE_FROM_TARGET = "검증 대상에서 제거"
BTN_MOVE_TO_EXCLUDE = "제외로 이동"
BTN_MOVE_TO_TARGET = "검증 대상으로 이동"
BTN_BACK_TO_CENTER = "중앙으로 복귀(재결정)"
BTN_BATCH_EXCLUDE = "일괄 제외"
BTN_BATCH_VERIFY = "일괄 검증으로 이동"
BTN_EXPORT_EXCEL = "엑셀로 저장"
BTN_OPEN_RESULT = "결과 폴더 열기"
BTN_NEW_SESSION = "새 검증 시작"
BTN_REVIEW_MATCHES = "매칭 결과 검토"

# ── 매칭 결과 검토 (#18) ───────────────────────────────────────────────────
REVIEW_DIALOG_TITLE = "매칭 결과 검토"
REVIEW_HINT = (
    "잘못 매칭된 행이 있으면 [삭제] 로 결과에서 제외할 수 있습니다.\n"
    "삭제된 항목은 엑셀 저장 시 결과에 포함되지 않습니다."
)
REVIEW_BTN_DELETE = "삭제"
REVIEW_REMOVED_FMT = "{n} 개의 매칭이 결과에서 제외되었습니다."

# ── 셋업 페이지 ────────────────────────────────────────────────────────────
SETUP_TITLE = "AOI 검증 — 시작 설정"
SETUP_MODE_LABEL = "검증 모드"
SETUP_MODE_SINGLE = "한쪽만 검증"
SETUP_MODE_CROSS = "양쪽 교차검증"
SETUP_REF_GROUP = "기준 장비"
SETUP_VAL_GROUP = "검증 장비"
SETUP_FOLDER_LABEL = "최상위 폴더"
SETUP_MACHINE_LABEL = "호기 번호"
SETUP_THRESHOLD_LABEL = "유사도 임계치"
SETUP_FOLDER_PLACEHOLDER = "폴더를 선택해 주세요"
SETUP_MACHINE_PLACEHOLDER = "예) 1호기"
SETUP_HINT = (
    "기준 장비와 검증 장비는 서로 다른 호기의 폴더입니다.\n"
    "두 폴더의 하위 Slot 폴더 이름이 같을 때 매칭됩니다."
)

# ── 검증 단계 헤더 ─────────────────────────────────────────────────────────
STAGE1_TITLE = "Stage 1 — 후보 선별"
STAGE2_TITLE = "Stage 2 — 유사도 기반 매칭"
RESULT_TITLE = "검증 결과"

PANEL_LEFT_CANDIDATES = "검증 후보들 (남은 사진)"
PANEL_CENTER_DECIDE = "검증 결정할 사진"
PANEL_RIGHT_TARGETS = "검증 대상 (검증하기로 한 사진들)"
PANEL_BOTTOM_EXCLUDED = "검증 하지 않을 사진 (제외됨)"

PANEL_SKIP_LIST = "Skip 된 사진들"
PANEL_MATCH_REF = "기준 사진"
PANEL_MATCH_CANDIDATES = "검증 장비 후보"

# ── 줌-뷰 윈도우 ───────────────────────────────────────────────────────────
ZOOM_TITLE_TARGETS = "검증 대상인 사진들 — {slot}"
ZOOM_TITLE_EXCLUDED = "검증 하지 않을 사진 — {slot}"
ZOOM_TITLE_CANDIDATES = "검증 후보 사진들 — {slot}"
ZOOM_BTN_EXCLUDE = "검증에서 제외"
ZOOM_BTN_TO_TARGET = "검증 대상으로 변경"
ZOOM_BTN_TO_CENTER = "재결정으로 복귀"
ZOOM_BTN_PICK_MATCH = "이 사진을 매칭으로 확정"

# ── 동일 사진 그룹 (#15) ───────────────────────────────────────────────────
GROUP_BTN_VIEW_FMT = "동일 그룹 보기 ({n}장)"
GROUP_DIALOG_TITLE_FMT = "동일 사진 그룹 — {slot}  ·  {n} 장"
GROUP_DIALOG_HINT = (
    "같은 슬롯 안에서 거의 동일한 사진이 자동으로 묶였습니다.\n"
    "사용자가 대표 사진에 내린 결정(검증/제외) 이 그룹 전체에 똑같이 적용됩니다.\n"
    "따로 결정하고 싶은 사진이 있으면 ‘그룹에서 분리’ 를 누르세요."
)
GROUP_BTN_DETACH = "그룹에서 분리"

# ── 단축키 ────────────────────────────────────────────────────────────────
SHORTCUT_TOOLTIP = (
    "단축키:  ← 또는 1 = 검증   /   → 또는 2 = 제외   /   Z = 되돌리기"
)
SHORTCUT_STAGE2_TOOLTIP = "단축키:  S = 잠시 보류    N = 매칭 없음 확정"
PANEL_NO_MATCH_LIST = "매칭 없음 확정"

# ── 사진 크기 슬라이더 ────────────────────────────────────────────────────
IMAGE_SIZE_LABEL = "사진 크기"
SLOT_LABEL_FMT = "Slot: {slot}"

# ── 셋업 화면 사용 설명 ────────────────────────────────────────────────────
SETUP_HOW_TO_USE_TITLE = "사용 방법"
SETUP_HOW_TO_USE_BODY = (
    "① 검증 모드를 선택합니다  ·  한쪽만 검증 / 양쪽 교차검증\n"
    "② 기준 장비와 검증 장비의 폴더와 호기 번호를 입력합니다\n"
    "③ 유사도 임계치를 조정합니다  (기본 70%)\n"
    "④ [검증 시작] 을 누르면 다음 순서로 진행됩니다\n"
    "      ㄱ. 후보 선별 — 결정할 사진을 한 장씩 보면서 [✓ 검증] / [✕ 제외]\n"
    "      ㄴ. 유사도 매칭 — 기준 사진별로 가장 비슷한 검증 사진을 선택\n"
    "      ㄷ. 결과 저장 — 양식 폴더의 양식.xlsx 를 복사하여 자동 저장\n"
    "단축키 — ← / 1 = 검증,  → / 2 = 제외,  Z = 되돌리기,  S = 건너뛰기"
)

# ── 양식 파일 / 저장 파일 명명 ─────────────────────────────────────────────
TEMPLATE_DIR_NAME = "양식"
TEMPLATE_FILE_NAME = "양식.xlsx"
RESULT_FILE_TITLE_FMT = "AOI {val} 검증 ({ref} 기준).xlsx"
TEMPLATE_NOT_FOUND_TITLE = "양식 파일 없음"
TEMPLATE_NOT_FOUND_BODY = (
    "‘양식’ 폴더 안의 ‘양식.xlsx’ 를 찾을 수 없습니다.\n"
    "기본 양식으로 결과를 생성합니다.\n\n"
    "확인한 경로: {path}"
)
WORKING_FILE_READY_FMT = "결과 파일이 준비되었습니다:\n{path}"
WORKING_FILE_LABEL = "결과 파일 위치"

# ── 학습 모델 / 동의 / 정확도 ──────────────────────────────────────────────
CONSENT_TITLE = "학습 데이터 사용 동의"
CONSENT_BODY_FMT = (
    "이번 세션의 매칭 쌍 {n} 개를\n"
    "유사도 모델의 학습 데이터로 추가할까요?\n\n"
    "(다음 [모델 재학습] 시 반영됩니다.\n"
    " 매칭되지 않은 사진은 사용하지 않습니다.)"
)
CONSENT_OK_FMT = "학습 데이터 {n} 쌍이 추가되었습니다."
CONSENT_FAIL_FMT = "학습 데이터 저장 실패: {error}"

MODEL_CARD_TITLE = "학습 모델"
MODEL_OPTION_BASIC = "기본 탐지 모드 (학습 모델 미사용)"
MODEL_OPTION_FMT = (
    "{name}  ·  {pairs}쌍 학습  ·  Hit@5 {hit5}% [{lo}~{hi}]  ·  {evals}회"
)
MODEL_OPTION_NO_ACC_FMT = "{name}  ·  {pairs}쌍 학습  ·  평가 데이터 부족"
MODEL_OPTION_BASELINE_FMT = (
    "기본 탐지 모드  ·  Hit@5 {hit5}% [{lo}~{hi}]  ·  {evals}회 평가"
)
MODEL_DELTA_FMT = "  (vs 기본 모드: {sign}{delta}%p)"
MODEL_WEAKEST_SLOT_FMT = "최약 슬롯: {slot}  ·  Hit@5 {hit5}%  ·  {picks}회"
MODEL_DATA_COUNT_FMT = "수집된 학습 데이터: {n} 쌍"
MODEL_NO_TORCH = "torch 가 설치되어 있지 않아 학습 기능을 사용할 수 없습니다."

BTN_RETRAIN = "모델 재학습 시작"
BTN_REFRESH_ACC = "정확도 갱신"
BTN_DELETE_MODEL = "모델 삭제"
BTN_EXPORT_MODEL = "내보내기"
BTN_IMPORT_MODEL = "가져오기"
EXPORT_DIALOG_TITLE = "모델 내보내기"
IMPORT_DIALOG_TITLE = "모델 가져오기"
EXPORT_DONE_FMT = "모델을 내보냈습니다:\n{path}"
IMPORT_DONE_FMT = "모델 ‘{name}’ 을 가져왔습니다."
EXPORT_FAIL_FMT = "내보내기 실패: {error}"
IMPORT_FAIL_FMT = "가져오기 실패: {error}"

LOAD_BACKBONE_FMT = "백본 임베딩 추출 중… {done} / {total}"
LOAD_TRAIN_FMT = "헤드 학습 중… 에폭 {epoch} / {total}  ·  loss {loss:.3f}"

TRAIN_DONE_FMT = "모델 ‘{name}’ 학습 완료. 다음 검증부터 적용됩니다."
TRAIN_FAIL_FMT = "학습 실패: {error}"
TRAIN_NEED_MORE_DATA = (
    "학습 데이터가 부족합니다. 매칭 쌍을 더 모은 뒤 다시 시도해 주세요."
)
TRAIN_CONFIRM_TITLE = "모델 재학습"
TRAIN_CONFIRM_BODY_FMT = (
    "현재 수집된 {n} 쌍의 데이터로 새 모델을 학습합니다.\n"
    "기존 모델은 그대로 유지되고, 새 모델이 생성됩니다.\n"
    "계속할까요?"
)

DELETE_CONFIRM_TITLE = "모델 삭제"
DELETE_CONFIRM_BODY_FMT = (
    "‘{name}’ 모델을 삭제하시겠습니까?\n"
    "가중치 파일, 메타 정보, 평가 로그가 모두 제거됩니다."
)

ACC_REFRESH_NO_CHANGE = "갱신할 모델이 없거나, 평가 데이터가 부족합니다."
ACC_REFRESH_DONE_FMT = "정확도 갱신 완료. {renamed} 개의 모델 파일이 변경되었습니다."

MODEL_TOOLTIP = (
    "정확도 = 모델 추천 순위와 사용자가 실제 선택한 후보의 일치도입니다.\n"
    "같은 슬롯에 중복 사진이 많을 경우 절대값보다는 모델 간 비교용으로 보세요."
)

# ── 로딩/진행 ──────────────────────────────────────────────────────────────
LOAD_THUMBNAIL_FMT = "썸네일 생성 중… {done} / {total}"
LOAD_FEATURE_FMT = "검증 장비 특징 추출 중… {done} / {total}"
LOAD_SCAN = "폴더 스캔 중…"
LOAD_EXPORT = "엑셀로 저장 중…"
LOAD_PRECOMPUTE_REF = "기준 장비 특징 추출 중… {done} / {total}"

# ── 경고/안내 모달 ─────────────────────────────────────────────────────────
WARN_SAME_PATH_TITLE = "경로 확인"
WARN_SAME_PATH_BODY = (
    "기준 장비와 검증 장비의 경로가 동일합니다.\n"
    "정말로 같은 폴더를 비교하시겠습니까?"
)
WARN_PATH_NOT_EXIST = "선택한 경로가 존재하지 않습니다:\n{path}"
WARN_NO_SLOTS = "두 폴더에 공통된 Slot 이 존재하지 않습니다."
WARN_NO_IMAGES = "선택된 Slot 에 이미지가 없습니다."
WARN_SLOT_MISMATCH_TITLE = "Slot 불일치"
WARN_SLOT_MISMATCH_FMT = (
    "한쪽에만 존재하는 Slot 이 있습니다.\n"
    "사용자가 직접 슬롯 매핑을 정해주실 수 있습니다.\n\n"
    "기준 전용: {ref_only}\n검증 전용: {val_only}"
)
SLOT_MAP_TITLE = "Slot 수동 매핑"
SLOT_MAP_HINT = (
    "한쪽에만 존재하는 슬롯을 사용자가 직접 짝지어 줄 수 있습니다.\n"
    "예) 기준 ‘Slot_01’ ↔ 검증 ‘S01’ 처럼 명명 규칙이 다를 때 사용하세요.\n"
    "짝지어지지 않은 슬롯은 매칭에서 제외됩니다."
)
SLOT_MAP_REF_LABEL = "기준"
SLOT_MAP_VAL_LABEL = "검증"
SLOT_MAP_ADD = "추가"
SLOT_MAP_REMOVE = "선택 해제"
SLOT_MAP_OPEN = "매핑 다이얼로그 열기"

# ── 화면 크기 프리셋 ───────────────────────────────────────────────────────
MENU_VIEW = "화면 크기"
WINDOW_PRESETS = [
    # 작게: 1366×768 노트북(taskbar 빼면 ~728 가용) 에서 잘리지 않게 720.
    # 가로는 MatchPage min-sum(200/420/440 + spacing + 여백 = 1112) 가 들어
    # 가도록 1120.  SelectPage 세로 컨텐츠가 ~722 라 720 은 빠듯하지만 하단
    # 패널 안의 스크롤이 흡수해 준다.
    ("작게",       1120, 720),
    ("보통",       1280, 820),
    ("크게",       1500, 940),
    ("매우 크게",  1760, 1080),
    ("최대화",     0,    0),       # (0,0) = showMaximized
]

# ── 임계치 자동 추천 ───────────────────────────────────────────────────────
THRESHOLD_SUGGESTION_TITLE = "임계치 추천"
THRESHOLD_SUGGESTION_FMT = (
    "스캔된 데이터의 분포를 분석한 결과 임계치 {suggested:.2f} 를 추천합니다.\n"
    "(현재 설정: {current:.2f})\n\n"
    "같은 슬롯 점수 — 중앙값 {same_median:.2f},  최소 {same_min:.2f}\n"
    "다른 슬롯 점수 — 중앙값 {diff_median:.2f},  최대 {diff_max:.2f}\n"
    "분포 간 여유: {margin:+.2f}\n\n"
    "추천 값으로 변경하시겠습니까?"
)
INFO_RESUME_TITLE = "이전 검증 이어하기"
INFO_RESUME_BODY = "진행 중인 검증이 있습니다. 이어서 하시겠습니까?"
INFO_NEW_SESSION = "새로 시작"
INFO_RESUME = "이어서 하기"
INFO_PHASE_TRANSITION_TITLE = "단계 전환"
INFO_PHASE_A_TO_MATCH = "Phase A 후보 선별이 끝났습니다. 매칭으로 넘어갑니다."
INFO_PHASE_A_TO_B = "Phase A 가 끝났습니다. 이어서 Phase B (역방향) 를 시작합니다."
INFO_PHASE_B_TO_MATCH = "Phase B 후보 선별이 끝났습니다. 매칭으로 넘어갑니다."
INFO_ALL_DONE = "모든 검증이 끝났습니다. 결과를 저장해 주세요."
INFO_NO_MATCH_FOUND = "임계치 이상인 후보가 없습니다. 자동으로 Skip 처리됩니다."
INFO_ALREADY_MATCHED_SECTION = "이미 매칭됨 (자동 제외)"

# ── 페이즈 표시 ────────────────────────────────────────────────────────────
PHASE_LABEL_FMT = (
    "Phase A: {a_ref} 기준 선별 → Phase A: 매칭 → "
    "Phase B: {b_ref} 기준 선별 → Phase B: 매칭 → 결과 저장"
)
PHASE_A_SELECT = "Phase A — 후보 선별"
PHASE_A_MATCH = "Phase A — 매칭"
PHASE_B_SELECT = "Phase B — 후보 선별 (역방향)"
PHASE_B_MATCH = "Phase B — 매칭 (역방향)"

# ── 저장/엑셀 ──────────────────────────────────────────────────────────────
SAVE_DIALOG_TITLE = "결과 엑셀 저장 위치 선택"
SAVE_FILENAME_FMT = "AOI검증결과_{ref}_vs_{val}_{ts}.xlsx"
SAVE_SUCCESS_FMT = "엑셀 저장 완료:\n{path}"
SAVE_FAIL_FMT = "엑셀 저장 실패:\n{error}"
EXPORT_TEMPLATE_NOT_FOUND = (
    "양식.xlsx 템플릿을 찾을 수 없습니다. 기본 양식으로 저장합니다."
)
SHEET_MISS_FAST = "미탐_빠른호기"
SHEET_MISS_SLOW = "미탐_늦은호기"
SLOT_MISMATCH_SHEET = "Slot 불일치 목록"

# ── 일반 상태 표시 ─────────────────────────────────────────────────────────
SLOT_COUNT_FMT = "{slot}: 기준 {ref}장 / 검증 {val}장"
COUNT_PLUS_N_FMT = "+{n}"
PROGRESS_SLOT_FMT = "{slot}  ·  {done} / {total}"
GROUP_HEADER_FMT = "{slot}  ·  {count} 장"

# ── 오류 ────────────────────────────────────────────────────────────────
ERR_GENERIC = "오류가 발생했습니다: {error}"
ERR_LOAD_IMAGE_FMT = "이미지를 불러올 수 없습니다: {path}"
ERR_FEATURE_FMT = "특징 추출 실패: {path}"
