"""추론 wrapper — 활성화된 모델(또는 basic 모드)에 따라 임베딩을 만든다.

도메인 특화 전처리 적용 (#9):
- 중심 ROI + CLAHE + 가벼운 Gaussian blur (image_io.preprocessed_roi_gray)
- 1-채널 gray 를 3-채널로 복제하여 ImageNet 통계로 정규화
- 입력 해상도 256 (백본 224 보다 약간 키워 디테일 보존)

배치 추론(#12):
- ``compute_embeddings([paths])`` 가 32 씩 배치로 forward 해서 CPU 속도 5~10×.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Iterable, Optional, Tuple

import numpy as np

from ..utils import image_io
from . import registry, triplet_model

try:  # pragma: no cover — optional
    import torch
    from torchvision import models
    _HAS_TORCH = True
except Exception:  # pragma: no cover
    torch = None  # type: ignore
    models = None  # type: ignore
    _HAS_TORCH = False


_INPUT_PX = 256
_IMAGENET_MEAN = (0.485, 0.456, 0.406)
_IMAGENET_STD = (0.229, 0.224, 0.225)
_DEFAULT_BATCH = 32


def is_available() -> bool:
    return _HAS_TORCH and triplet_model.is_available()


# ---------------------------------------------------------------------------
# Active mode
# ---------------------------------------------------------------------------
def get_active_mode() -> str:
    return registry.get_active()


def set_active_mode(name: str) -> None:
    registry.set_active(name)
    _load_head_for.cache_clear()


# ---------------------------------------------------------------------------
# Backbone (lru_cache singleton)
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _load_backbone():  # pragma: no cover — heavy
    if not _HAS_TORCH:
        raise RuntimeError("torch 가 설치되어 있지 않습니다")
    weights = models.MobileNet_V3_Small_Weights.IMAGENET1K_V1
    backbone = models.mobilenet_v3_small(weights=weights)
    backbone.classifier = torch.nn.Identity()
    backbone.eval()
    return backbone


def load_backbone():  # pragma: no cover — heavy
    """학습 워커가 backbone 인스턴스를 공유하기 위한 공개 진입점."""
    return _load_backbone()


@lru_cache(maxsize=8)
def _load_head_for(model_name: str):  # pragma: no cover — heavy
    if model_name == registry.BASIC:
        return None
    info = registry.find(model_name)
    if info is None or not info.weights_path.exists():
        return None
    try:
        head = triplet_model.load_head(info.weights_path)
        head.eval()
        return head
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Tensor preparation — domain-preprocessed gray-3ch input
# ---------------------------------------------------------------------------
def _make_input_tensor(path: Path):  # pragma: no cover
    """1장의 도메인 전처리 텐서를 만든다 (3, H, W) float32, ImageNet 정규화."""
    if not _HAS_TORCH:
        return None
    try:
        gray = image_io.preprocessed_roi_gray(path, long_edge=_INPUT_PX)
    except Exception:
        return None
    # (H, W) → (3, H, W)
    arr = np.repeat(gray[None, :, :], 3, axis=0).astype(np.float32) / 255.0
    # ImageNet 정규화 (gray 복제이긴 하지만 일관성 위해 적용)
    for c, (mean, std) in enumerate(zip(_IMAGENET_MEAN, _IMAGENET_STD)):
        arr[c] = (arr[c] - mean) / std
    return torch.from_numpy(arr)


# ---------------------------------------------------------------------------
# Public — single image
# ---------------------------------------------------------------------------
def compute_embedding(src: Path) -> Optional[np.ndarray]:
    """현재 활성 모델로 한 이미지의 임베딩(unit 정규화 1-D 벡터)을 만든다."""
    if not is_available():
        return None
    mode = get_active_mode()
    if mode == registry.BASIC:
        return None
    out = compute_embeddings([src])
    return out.get(Path(src))


def compute_embeddings(paths: Iterable[Path],
                       *,
                       batch_size: int = _DEFAULT_BATCH
                       ) -> dict[Path, np.ndarray]:
    """여러 이미지의 임베딩을 배치로 계산. basic 모드면 빈 dict."""
    out: dict[Path, np.ndarray] = {}
    if not is_available():
        return out
    mode = get_active_mode()
    if mode == registry.BASIC:
        return out

    backbone = _load_backbone()
    head = _load_head_for(mode)

    items = [Path(p) for p in paths]
    if not items:
        return out

    pending: list[Tuple[Path, "torch.Tensor"]] = []

    def _flush_batch() -> None:
        if not pending:
            return
        keys = [p for p, _ in pending]
        tensors = [t for _, t in pending]
        x = torch.stack(tensors)
        with torch.no_grad():
            feat = backbone(x)
            if head is not None:
                feat = head(feat)
            feat = feat.cpu().numpy()
        # L2 정규화
        norms = np.linalg.norm(feat, axis=1, keepdims=True) + 1e-9
        feat = (feat / norms).astype(np.float32)
        for k, v in zip(keys, feat):
            out[k] = v
        pending.clear()

    for p in items:
        t = _make_input_tensor(p)
        if t is None:
            continue
        pending.append((p, t))
        if len(pending) >= batch_size:
            _flush_batch()
    _flush_batch()
    return out


def cosine_similarity(a: Optional[np.ndarray],
                      b: Optional[np.ndarray]) -> float:
    if a is None or b is None or a.size == 0 or b.size == 0:
        return 0.0
    if a.shape != b.shape:
        return 0.0
    dot = float(np.dot(a, b))
    return max(0.0, min(1.0, (dot + 1.0) / 2.0))


def invalidate_caches() -> None:
    """모델 파일이 새로 학습/리네임된 후 호출."""
    _load_head_for.cache_clear()


def make_input_tensor(path: Path):  # pragma: no cover — 외부 노출(트레이너용)
    return _make_input_tensor(path)
