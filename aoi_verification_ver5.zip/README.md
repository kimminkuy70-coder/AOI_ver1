# AOI 검증 프로그램

> 한국어 사용자 인터페이스(GUI)를 제공하는 AOI(자동 광학 검사) 검증 도구입니다.

- **개발자:** 임현택 (HyunTaek Lim)
- **소속:** Bump 2 Dept. / AOI Engineer
- **실행 환경:** **VS Code** 에서 가상환경(`venv`) 으로 실행. PyInstaller 호환은 유지.

---

## 1. 사전 준비

- Windows 10/11
- **VS Code** 와 **Python 확장**(Microsoft 공식) 설치
- 시스템에 Python 3.10 이상이 깔려 있어야 함. (별도 Python 이 없으면
  Anaconda/Spyder 와 함께 깔린 Python 의 `python.exe` 경로를 활용해도 됨.)

## 2. 폰트 안내

한국어가 깨지지 않도록 다음 폰트 중 하나가 시스템에 설치되어 있어야 합니다.

- `Pretendard`
- `Noto Sans KR`
- `Malgun Gothic` (Windows 기본 — 보통은 이미 있음)

영문 타이틀은 `Orbitron`, 본문은 `Rajdhani` 를 우선 사용하며, 한글이 포함되면
한국어 폰트로 자동 폴백됩니다.

## 3. VS Code 에서 실행하기

### 3.1 프로젝트 폴더 열기

VS Code → `파일 → 폴더 열기` → 이 저장소 폴더(`coding-claude-aoi-verification-app-LAXpX`).

### 3.2 가상환경(`.venv`) 만들기

VS Code 안에서 **터미널 열기** (`Ctrl + ` ` 또는 메뉴 `Terminal → New Terminal`).
PowerShell 이 기본일 텐데 그대로 사용하면 됩니다.

```powershell
# Spyder 가 설치돼 있다면 그 Python 으로 venv 를 만드는 게 가장 안전:
& "C:\ProgramData\spyder-6\envs\spyder-runtime\python.exe" -m venv .venv

# Python 을 별도 설치했다면:
# py -m venv .venv
# 또는: python -m venv .venv
```

### 3.3 venv 활성화

```powershell
.\.venv\Scripts\Activate.ps1
```

> **PowerShell 실행 정책 오류** 가 나오면 한 번만:
> ```powershell
> Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
> ```
> 그래도 안 되면 `cmd` 스타일로: `.\.venv\Scripts\activate.bat`

프롬프트 앞에 `(.venv)` 가 붙으면 성공.

### 3.4 패키지 설치

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

5~10 분 소요. `torch` 가 가장 무겁습니다. **학습 모델을 안 쓸 거면**
`requirements.txt` 의 `torch` / `torchvision` 두 줄을 `#` 로 주석 처리하면
설치가 1 분 안에 끝납니다.

### 3.5 VS Code 에 venv 등록

1. **Ctrl + Shift + P** → `Python: Select Interpreter`
2. 목록에서 **`.venv (Python 3.x.x)`** 또는 다음 경로 선택:
   ```
   .\.venv\Scripts\python.exe
   ```
3. 우측 하단 상태바에 `Python 3.x.x ('.venv')` 가 떠야 정상.

### 3.6 실행

세 가지 방법 — 편한 것 사용:

| 방법 | 동작 |
| --- | --- |
| `main.py` 열고 **F5** | 디버거로 실행 (중단점 사용 가능) |
| 우측 상단 **▶ Run Python File** | 디버거 없이 빠르게 실행 |
| 터미널에 `python main.py` | 가장 단순 |

`AOI 검증` 창이 뜨면 성공입니다.

> 메인 진입점인 `main.py` 는 `QApplication.instance()` 를 재사용하므로 IDE
> 가 두 번째 실행할 때도 안전합니다. 디버그를 중간에 강제 종료해도 다음
> 실행에 영향을 주지 않습니다.

## 4. 폴더 구조 가정

```
[기준 장비 최상위 폴더]
├── Slot_01/
│   ├── image1.jpeg
│   └── ...
├── Slot_02/
└── ...

[검증 장비 최상위 폴더]   ← 기준 장비와 동일한 Slot 명을 사용해야 매칭됩니다
├── Slot_01/
├── Slot_02/
└── ...
```

- 두 최상위 폴더는 **서로 다른 호기(장비)** 의 결과물입니다.
- 같은 경로를 두 번 입력하면 경고 모달이 표시됩니다.
- 한쪽에만 존재하는 Slot 은 사용자가 직접 매핑하거나 결과 보고서의
  `Slot 불일치 목록` 시트에 기록됩니다.

## 5. 사용 흐름 (요약)

1. 모드 선택 (한쪽만 검증 / 양쪽 교차검증)
2. 기준·검증 장비 폴더와 호기 번호 입력, 유사도 임계치 설정 후 **`검증 시작`**
3. **Stage 1** — 후보 선별 (중앙 사진에 대해 `검증` 또는 `제외` 결정)
4. **Stage 2** — 유사도 기반 매칭 (기준 사진 1장에 대해 유사한 검증 사진 선택)
5. 결과를 `양식/양식.xlsx` 템플릿에 채워서 `결과/` 폴더에 자동 저장

## 6. 키보드 단축키

| 단축키 | 동작 |
| --- | --- |
| `←` 또는 `1` | 검증 |
| `→` 또는 `2` | 제외 |
| `Z` | 직전 결정 취소 (Undo) |
| `S` | Stage 2 에서 잠시 보류 |
| `N` | Stage 2 에서 매칭 없음 확정 |

## 7. 화면 크기 조정

상단 메뉴바 **`화면 크기`** → 5 가지 프리셋 중 선택:

- 작게 (1100×720)
- 보통 (1280×820)  ← 기본
- 크게 (1500×940)
- 매우 크게 (1760×1080)
- 최대화 (모니터 가득)

선택한 크기는 자동으로 저장되어 다음 실행에도 유지됩니다.

검증/매칭 화면 중앙의 사진 크기는 **300 ~ 700 px** 범위에서 슬라이더로
조절 가능합니다 (기본 400 px).

## 8. 캐시 위치

썸네일·중간 크기 이미지·세션 상태는 다음 경로에 저장됩니다.

```
C:\Users\<사용자>\.aoi_verification_cache\
├── thumbs\          ← 200 px 썸네일
├── mid\             ← 800 px 중간 이미지 (엑셀 임베드용)
├── features\        ← 유사도 특징 (.npz)
├── session\         ← 자동 저장 세션
├── training_data\   ← 매칭 쌍 (학습용)
├── models\          ← 학습된 모델 가중치 + 메타
├── evaluations\     ← 모델별 평가 로그
└── ui_prefs.json    ← 화면 크기·임계치·마지막 폴더 등
```

원본 폴더는 절대 수정하지 않습니다. 용량이 부담스러우면 폴더째 지워도 됩니다
(다음 실행 시 자동으로 다시 생성).

## 9. 결과 파일

- 위치: 프로젝트 루트의 `결과/` 폴더 (자동 생성)
- 파일 이름: `AOI {검증호기} 검증 ({기준호기} 기준).xlsx`
- 양식: `양식/양식.xlsx` 를 자동 인식. 헤더 위치(`Slot`, `기준`, `검증`,
  `방향`) 가 자동 감지되므로 어느 열에 두든 동작합니다.
- 교차 검증 모드에서는 `매칭 방향` 컬럼 + `미탐_빠른호기` / `미탐_늦은호기`
  시트가 자동 추가됩니다.

## 10. 학습 모델 (선택)

`torch`, `torchvision` 이 설치되어 있으면 매칭 결과를 모아 임베딩 모델의 투영
헤드를 fine-tune 할 수 있습니다.

### 10.1 데이터 수집

세션을 마치고 `[엑셀로 저장]` 까지 끝나면 다음 모달이 뜹니다.

> 이번 세션의 매칭 쌍 N 개를 유사도 모델의 학습 데이터로 추가할까요?

**[예]** 를 누르면 `~/.aoi_verification_cache/training_data/pairs.jsonl` 에 한 줄씩
append 됩니다. 매칭되지 않은 사진은 사용하지 않습니다 (같은 슬롯 안에 중복 사진이
많아 “정말 다르다” 라고 보장할 수 없기 때문).

### 10.2 모델 학습

셋업 화면의 **학습 모델** 카드에서 `[모델 재학습 시작]` 을 누르면
`~/.aoi_verification_cache/models/{YYYY-MM-DD}.pt` 가 생성됩니다. 같은 날 두 번째
학습은 `_2`, `_3` 으로 부여됩니다. 학습은 CPU 에서 수십 초~수 분 정도 걸립니다.

- 백본: MobileNetV3-Small (ImageNet 사전학습, frozen)
- 헤드: 1280 → 512 → 128 (`nn.Linear` + ReLU + `nn.Linear`)
- 손실: `nn.TripletMarginLoss(margin=0.3, p=2)`
- Anchor = 기준 사진 / Positive = 매칭된 검증 사진 /
  Negative = 같은 세션의 *다른 Slot* 에서 임의 샘플 (cross-slot only)
- 2 에폭부터는 semi-hard negative mining 으로 학습 효율 향상

### 10.3 모델 선택

학습 모델 카드의 라디오 버튼으로 다음 검증에 적용할 모델을 선택합니다.

- `기본 탐지 모드 (학습 모델 미사용)` — 기존 pHash/ORB/SSIM 만 사용.
- 날짜별 학습 모델 — CNN 임베딩이 자동으로 활성화되어 최종 유사도 점수에 가중치
  로 합산됩니다.

선택 즉시 `~/.aoi_verification_cache/models/active.txt` 에 저장되어 다음 실행에도
이어집니다.

모델 카드에는 다음이 표시됩니다.

- **`기본 탐지 모드 · Hit@5 65% [60~70]`** (95% Wilson 신뢰구간)
- **`2026-05-13_HitAt5_78 · 142 쌍 학습 · Hit@5 78% [73~83] · 217 회 평가`**
- **`(vs 기본 모드: +13%p)`** ← 베이스라인 대비 개선폭
- **`최약 슬롯: Slot_A02 · Hit@5 32% · 28 회`** ← 모델이 헤매는 슬롯

### 10.4 정확도 평가

Stage 2 에서 사용자가 어떤 후보를 몇 번째 순위에서 클릭했는지를
`~/.aoi_verification_cache/evaluations/{model_name}.jsonl` 에 한 줄씩 기록합니다.
셋업 화면 진입 시 자동으로 다시 집계되고, 다음 지표가 메타·UI 에 반영됩니다.

- **Hit@1 / Hit@5 / Hit@8** — 사용자가 클릭한 후보가 모델의 상위 N 위 안에 있던
  비율 (주 표기 지표 = **Hit@5**)
- **Pick rate** — 모델 추천이 ‘받아들여진’ 비율
- **Mean rank** — 사용자가 클릭한 평균 순위 (1-based)

평가 횟수가 10 회 이상이고 Hit@5 가 이전 표기값과 2%p 이상 차이 나면 파일이
자동으로 **`{date}_HitAt5_{n}.pt`** 형태로 리네임됩니다. 수동으로 강제하려면
**`[정확도 갱신]`** 버튼을 누르세요.

> ⓘ 정확도는 “모델 추천 순위와 사용자가 실제 선택한 후보의 일치도” 입니다.
> 같은 슬롯에 중복 사진이 많을 경우 절대값보다는 *모델 간 비교* 의 의미로
> 보세요.

### 10.5 모델 내보내기 / 가져오기 / 삭제

- **`[내보내기]`** — 현재 활성 모델을 `.zip` 으로 묶어 다른 PC 로 전달 가능.
  가중치·메타·평가 로그가 모두 포함됩니다.
- **`[가져오기]`** — 다른 PC 에서 받은 `.zip` 을 그대로 import.
  이름 충돌 시 `_2`, `_3` 자동 부여.
- **`[모델 삭제]`** — 활성 모델의 가중치·메타·평가 로그를 한꺼번에 제거.
  기본 모드는 삭제 대상이 아닙니다.

## 11. 트러블슈팅

| 증상 | 원인 / 해결 |
| --- | --- |
| VS Code 가 venv 의 python 을 못 잡음 | `Ctrl+Shift+P` → `Python: Clear Cache and Reload Window` 시도 후 다시 Select Interpreter |
| F5 실행 시 “Reach Python interpreter” 에러 | venv 활성화가 안 된 터미널에서 실행한 것. 위 3.5 단계 다시 확인 |
| `pip install` 이 매우 느림 | `torch` 가 가장 무거움. 학습 기능을 쓰지 않을 거면 `requirements.txt` 에서 주석 처리 |
| 회사 프록시 환경 | `pip install --proxy http://프록시주소:포트 -r requirements.txt` |
| 한글이 ▯ 로 깨짐 | `Malgun Gothic` 또는 `Pretendard` 설치 확인 |
| `AOI 검증` 창이 안 뜨고 콘솔에 traceback | 메시지 그대로 알려주세요 — 의존성 누락이 가장 흔합니다 |
| `_HAS_TORCH = False` 같은 메시지가 떠도 됨 | torch 가 없으면 학습/CNN 기능만 비활성. 기본 모드는 정상 동작 |

## 12. 단위 테스트

```powershell
python -m pytest -q
```

25 개 테스트가 5 초 안에 끝납니다.  PyQt 도, torch 도 필요 없는 빠른 회귀
테스트입니다.

## 13. 라이선스 / 문의

내부 사용용 도구입니다. 개선 요청은 개발자에게 전달해 주세요.
